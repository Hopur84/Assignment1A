#include "Order.h"



ostream& operator <<(ostream& out, const Order& order)
{
    out << "Customer: " << order.customer << endl;
    out << "Crust: " << order.crust << endl << "Toppings:";
    for(int i = 0; i < 10; i++)
    {
        out << " " << order.toppings[i];
    }
    out << "price: " << order.price << endl;
    
    return out;
}


Order::Order()
{
    crust = "Classic";
    price = 1000;
    Size = 1;
}

void Order::set_size()
{
    int input;
    bool stop = false;

    while(stop == false)
    {
        cout << "0. Cancel" << endl << "1. Large" << endl << "2. mid" << endl << "3. small" << endl;
        cin >> input;
        switch(input)
    {
        case 0:
            stop = true;
            break;
        case 1:
            Size = 2;
            stop = true;
            break;
        case 2:
            Size = 1;
            stop = true;
            break;
        case 3:
            Size = 0.5;
            stop = true;
        default:

            break;
        }
    }
}

void Order::customer_order()
{
    cout << "Customer name: ";
    cin >> customer;
}

void Order::pick_crust()
{

    ifstream fin;
    fin.open("crust.txt");
    string str;

    int input = 0;
    cout << "0. Cancel" << endl;
    for(int i = 0; i<4; i++)
    {
        getline(fin, str);
        topping_list[i] = str;
        cout << i+1 << "." << str << endl;
    }
    cout << endl;

    cin >> input;

    if(input !=0)
    {
    crust = topping_list[input-1];
    }
    else{}
    fin.close();

}

void Order::pick_topping()
{
    ifstream fin;
    string str;
    int input;
    int number = 0;
    bool stop = false;

    while(stop == false)
    {
        cout << "press '0' to go back" << endl << endl << "1.Meats: " << 150*Size << "kr"
             << endl << "2.Greens: " << 100*Size << "Kr" << endl << "3.cheeses: " << 200*Size << "kr"
             << endl << "4.sauces and spices: " << 120*Size << "kr" << endl;
        cin >> input;
        switch(input)
        {
        case 1:
            fin.open("meats.txt", ios::app);
            if(fin.is_open())
            {
                cout << "0. Cancel" << endl;
                for(int i = 0; i < 7; i++)
                {
                    if(!fin.eof())
                    {
                        cout << i+1 << ".";
                        getline(fin, str);
                        topping_list[i] = str;
                        cout << str << endl;
                    }
                }
                cout << endl;
                cin >> input;
                if(input == 0)
                {
                    pick_topping();
                }
                else
                {
                    price+= 150*Size;
                }
                toppings[number] = topping_list[input-1];
            }
            fin.close();
            break;
        case 2:
            fin.open("greens.txt", ios::app);
            if(fin.is_open())
            {
                cout << "0. Cancel" << endl;
                for(int i = 0; i < 7; i++)
                {
                    if(!fin.eof())
                    {
                        cout << i+1 << ".";
                        getline(fin, str);
                        topping_list[i] = str;
                        cout << str << endl;
                    }
                }
                cout << endl;
                cin >> input;
                if(input == 0)
                {
                    pick_topping();
                }
                else
                {
                    price+=100*Size;
                }
                toppings[number] = topping_list[input-1];
            }
            fin.close();
            break;
        case 3:
            fin.open("cheeses.txt", ios::app);
            if(fin.is_open())
            {
                cout << "0. Cancel" << endl;
                for(int i = 0; i < 4; i++)
                {
                    if(!fin.eof())
                    {
                        cout << i+1 << ".";
                        getline(fin, str);
                        topping_list[i] = str;
                        cout << str << endl;
                    }
                }
                cout << endl;

                cin >> input;

                if(input == 0)
                {
                    pick_topping();
                }
                else
                {
                    price+=200*Size;
                }
                toppings[number] = topping_list[input-1];
            }
            fin.close();
            break;
        case 4:
            fin.open("sauces_&_spices.txt", ios::app);
            if(fin.is_open())
            {
                cout << "0. Cancel" << endl;
                for(int i = 0; i < 7; i++)
                {
                    if(!fin.eof())
                    {
                        cout << i+1 << ".";
                        getline(fin, str);
                        topping_list[i] = str;
                        cout << str << endl;
                    }
                }
                cout << endl;
                cin >> input;
                if(input == 0)
                {
                    pick_topping();
                }
                else
                {
                    price+=120*Size;
                }
                toppings[number] = topping_list[input-1];
            }
            fin.close();
            break;
        case 0 :
            stop = true;
            break;
        default:
            break;
        }
        number++;
    }
}

void Order::premade_pizzas()
{
    ifstream fin;
    ofstream fout;
    int premade_input = 0;
    
    
    fin.open("PreMadePizzas.txt");
    string str;
    
    if(fin.is_open())
    {
        while(!fin.eof())
        {
            getline(fin, str);
            cout << str << endl;
        }
    }
    else
    {
        cout << "error";
    }
    fin.close();
    fout.open("orders.txt");
    
    
    cout << "Pick a pizza(1-3),to go back to menu, press ?: ";  //Þarf að geta ýtt á eitthvað til að komast til baka.
    cin >> premade_input;
    fout << "Customer name: " << customer << endl;
    
    //Þarf að gera rétt price í textaskjalinu, gerði bara eitthvað til að testa functionið.
    switch (premade_input)
    {
        case 1:
            fout << "Crust: Classic" << endl << "Toppings:  Cheese" << endl;
            break;
            
        case 2:
            fout << "Crust: Deep Dish" << endl << "Toppings: Cheese, Paprika, Mushroom, Garlic, Olives" << endl;
            break;
            
        case 3:
            fout << "Crust: Classic" << endl << "Toppings: Cheese, Pepperoni, Ham, BaconCrumbles" << endl;
            break;
    }
    fout << "Order status: processing" << endl;
    
    
}

void Order::baker()
{
    
    ifstream fin;
    ofstream fout;
    string str;
    
    fin.open("orders.txt");
    
    
    cout << "1. In oven" << endl;
    cout << "2. Ready" << endl;
    cout << "Status(1-2): ";
    cin >> order_status_input;
    
    switch (order_status_input)
    {
        case 1: order_status = "In oven";
            break;
        case 2: order_status = "Ready";
            break;
    }
    
    fin.close();
    
    
    fout.open("orders.txt");
    fout << "Customer: " << customer << endl;
    fout << endl;
    fout << "Crust: " << crust << endl;;
    fout << "Toppings: ";
    for(int i = 0; i<10; i++)
    {
        fout << toppings[i] << " ";
    }
    
    fout << endl;
    fout << "Order status: " << order_status << endl;;
    
    fout.close();
}


void Order::send_order()
{
    fstream fout;
    cout << endl << endl << endl << "Crust: " << crust << endl << "Toppings:";
    for(int i = 0; i < 10; i++)
    {
        cout << " " << toppings[i];
    }
    cout << endl << "Price: " << price;

}
